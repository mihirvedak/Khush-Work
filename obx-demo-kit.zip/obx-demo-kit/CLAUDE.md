# CLAUDE.md - OBX x Faclon Operations Demo

Client demo for **Open Book Extracts (OBX), Roxboro NC**, built by Faclon Labs on the I/O Sense stack.
Two process lines: **L1 Kratom / MIT** and **L2 Bulk Cannabinoids**. Synthetic but plant-accurate data.

## Always
- Read `.claude/skills/obx-faclon-ops-demo/SKILL.md` before any task and obey its 10 hard rules.
- The plant model (assets, tags, reasons, IDs) comes only from `references/01-line-knowledge.md`. Forms come only from `src/data/forms.ts` (`FORMS`). Colours / type / components only from `references/08-design-theme.md`. Never invent names, IDs, form fields or hex colours.
- Data: import from `src/data/index.ts` and call `buildDataset()`. Do not edit `src/data/generator.ts` or `types.ts`; if data must change, change `seed-data/` and re-copy, and say so.
- Plan first for anything touching more than 2 files; wait for OK.
- Finish every task with `npm run check` green (typecheck + tests).

## Stack (fixed - do not add libraries without asking)
Vite, React 18, TypeScript strict, Tailwind (Faclon CSS-variable tokens), ECharts via echarts-for-react, TanStack Table v8 + react-virtual, Zustand, date-fns-tz (America/New_York), react-router v6, lucide-react, vitest.

## Commands
- `npm run dev` - local demo
- `npm run check` - tsc --noEmit + vitest
- `npm run build` - production build
- `cd seed-data && npx tsx export-samples.ts` - regenerate `seed-data/sample/*.json`

## Build order
Slash commands `/p0-scaffold` -> `/p1-shell` -> then `/p2-overview` ... `/p9-genealogy` in any order -> `/p10-polish`.
One command per session; `/clear` between them; commit after each (`feat(p3): machine timeline`).

## Demo facts to keep consistent
- Demo "now" = 2026-09-22 16:20 ET, seed 2609. Shift A 06:00-18:00, shift B 18:00-06:00.
- Opening story: L2-WFE-2M down since 07:42 (E102 vacuum pump oil degraded, 0.184 mbar), tagged by J. Alvarez; shift B WFE-2M OEE gap; CRY-02 pH probe drift; ISO-C slow crash live; outdoor-pad DISC back-filled 24 min; untagged L1-LLE stop 13:31-14:05.
- Line OEE = constraint asset (L1: CRY-01/02, L2: WFE-2M). Yield is never inside OEE Quality.
- Every value shows a source badge; every non-OBX limit shows "Demo limit - pending OBX Quality"; top bar shows "Demo data - synthetic".
- Never show Faclon writing to a PLC / controller.

## Definition of done (per screen)
Real OBX names everywhere, units in every header, no `NaT`/`null`/"Machine 1" on screen, keyboard reachable, state never colour-only, loading/empty/error states, acceptance criteria of the matching reference file met.
