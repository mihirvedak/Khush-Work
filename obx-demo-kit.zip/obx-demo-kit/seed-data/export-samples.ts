import { writeFileSync } from 'fs';
import { buildDataset as buildDemoDataset, computeOee, getSeries, goldenTunnel, capability, eventAt, reasonLabel, shiftOf, FORMS } from './index';
const out = './sample/';
const ds = buildDemoDataset();
const iso = (t:number)=> new Date(t).toISOString();
// full dataset with ISO timestamps for readability
const conv = (o:any):any => Array.isArray(o)? o.map(conv) : o && typeof o==='object' && !(o instanceof RegExp) ? Object.fromEntries(Object.entries(o).map(([k,v])=>[k, (/^(start|end|at|dueAt|submittedAt|taggedAt|startedAt|ackAt|from|to)$/.test(k) && typeof v==='number')? iso(v): conv(v)])) : o instanceof RegExp ? String(o) : o;
writeFileSync(out+'dataset_30d.json', JSON.stringify(conv(ds)));
// small per-module slices
const last24 = ds.meta.to - 24*3.6e6;
writeFileSync(out+'timeline_L2-WFE-2M_last24h.json', JSON.stringify(conv(ds.events.filter(e=>e.assetId==='L2-WFE-2M' && (e.end??ds.meta.to) > last24)), null, 1));
const oee = ds.assets.map(a=>{ const all=computeOee(ds,{assetIds:[a.id],from:ds.meta.from,to:ds.meta.to}); const A=computeOee(ds,{assetIds:[a.id],from:ds.meta.from,to:ds.meta.to,shift:'A'}); const B=computeOee(ds,{assetIds:[a.id],from:ds.meta.from,to:ds.meta.to,shift:'B'}); const r=(x:number)=>Math.round(x*1000)/10; return {asset:a.id,line:a.line,constraint:a.isConstraint,A:r(all.availability),P:r(all.performance),Q:r(all.quality),OEE:r(all.oee),shiftA_OEE:r(A.oee),shiftB_OEE:r(B.oee),runH:Math.round(all.hours.run),unplannedH:Math.round(all.hours.unplanned),plannedH:Math.round(all.hours.planned),kgOut:Math.round(all.kg.total)}; });
writeFileSync(out+'oee_summary_30d.json', JSON.stringify(oee,null,1));
const s = (a:string,k:string,from:number,step:number)=>{ const x=getSeries(ds,a,k,from,ds.meta.to,step); return {asset:a,tag:k,stepSec:step,t:x.t.map(iso),v:x.v}; };
writeFileSync(out+'series_samples.json', JSON.stringify({
  wfe2m_24h: ['EVAP_PV','VAC_PV','FEED_PV','COND_PV','WIPER_PV','CHL_PV'].map(k=>s('L2-WFE-2M',k,last24,60)),
  isoC_live_batch: ['T_INT','T_JKT'].map(k=>s('L2-ISO-C',k,ds.batches.find(b=>b.assetId==='L2-ISO-C'&&b.end===null)!.start,60)),
  rxn1_last_batch: (()=>{ const b=[...ds.batches].filter(b=>b.assetId==='L2-RXN-1'&&b.end).pop()!; const x=getSeries(ds,'L2-RXN-1','T_INT',b.start,b.end!,10); return {batch:b.id, metrics:b.metrics, t:x.t.map(iso), v:x.v}; })(),
  cry02_last_48h: ['PH','T_INT','DOSE_RATE'].map(k=>s('L1-CRY-02',k,ds.meta.to-48*3.6e6,60)),
  ext_t01_24h: ['LVL','TEMP','PH','RECIRC_FLOW'].map(k=>s('L1-EXT-T01',k,last24,60)),
}));
const gt = goldenTunnel(ds,'L2-ISO','T_INT',40);
writeFileSync(out+'golden_tunnel_ISO_T_INT.json', JSON.stringify(gt,null,0));
// capability snapshot
const steady = (a:string,k:string)=>{ const x=getSeries(ds,a,k,ds.meta.to-7*864e5,ds.meta.to,60); return x.v.filter((_,i)=>{const e=eventAt(ds,a,x.t[i]); return e?.state==='RUN'&&e.phase==='STEADY FEED';}); };
const per = (p:string,m:string)=>ds.batches.filter(b=>b.assetId.startsWith(p)&&b.metrics[m]!==undefined&&b.end).map(b=>b.metrics[m]);
const R=(c:any)=>c&&Object.fromEntries(Object.entries(c).map(([k,v])=>[k,typeof v==='number'?Math.round(v*1000)/1000:v]));
const cap = {
  'L2-WFE-2M EVAP_PV (170-180, 7d steady, n=5)': R(capability(steady('L2-WFE-2M','EVAP_PV'),170,180,5)),
  'L2-WFE-2M VAC_PV (USL 0.05, 7d steady, n=5)': R(capability(steady('L2-WFE-2M','VAC_PV'),undefined,0.05,5)),
  'L2-WFE-2M FEED_PV (3.0-4.0)': R(capability(steady('L2-WFE-2M','FEED_PV'),3,4,5)),
  'L2-WFE-1M EVAP_PV (145-155)': R(capability(steady('L2-WFE-1M','EVAP_PV'),145,155,5)),
  'L2-ISO crashEndT (USL -18, per crash)': R(capability(per('L2-ISO','crashEndT'),undefined,-18)),
  'L2-RXN preAcidT (50-55)': R(capability(per('L2-RXN','preAcidT'),50,55)),
  'L1-CRY finalPH (9.3-9.9)': R(capability(per('L1-CRY','finalPH'),9.3,9.9)),
  'L1-CRY-02 finalPH': R(capability(per('L1-CRY-02','finalPH'),9.3,9.9)),
};
writeFileSync(out+'capability_snapshot.json', JSON.stringify(cap,null,1));
// pareto
const par = (line:string)=>{ const m:Record<string,number>={}; let tot=0; for (const e of ds.events) if (e.line===line && ['DOWN','IDLE','HOLD','MICRO'].includes(e.state)) { const h=((e.end??ds.meta.to)-e.start)/3.6e6; tot+=h; m[e.reasonCode!]=(m[e.reasonCode!]||0)+h; } return Object.entries(m).sort((a,b)=>b[1]-a[1]).slice(0,12).map(([k,v])=>({code:k,label:reasonLabel(k),hours:Math.round(v*10)/10,pct:Math.round(1000*v/tot)/10})); };
writeFileSync(out+'downtime_pareto_30d.json', JSON.stringify({L1:par('L1'),L2:par('L2')},null,1));
writeFileSync(out+'open_items_now.json', JSON.stringify(conv({ongoing:ds.events.filter(e=>e.end===null), openDeviations:ds.deviations.filter(d=>d.status!=='Closed'), holds:ds.qualityLosses.filter(q=>q.status!=='Closed'), overdueLogs:ds.logbookEntries.filter(l=>l.status==='Overdue'||l.status==='Due').slice(0,20)}),null,1));
console.log(JSON.stringify(oee.map(o=>[o.asset,o.OEE,o.shiftA_OEE,o.shiftB_OEE])));
console.log(JSON.stringify(cap,null,0).slice(0,1500));
console.log(JSON.stringify(par('L1').slice(0,6)), JSON.stringify(par('L2').slice(0,6)));
console.log(ds.qualityLosses.length, ds.deviations.length, ds.logbookEntries.length, ds.escalations.length, ds.events.length, ds.batches.length);
// form schema + schema-conformant logbook entries
writeFileSync(out+'forms_schema.json', JSON.stringify(FORMS, null, 1));
writeFileSync(out+'logbook_entries.json', JSON.stringify(conv(ds.logbookEntries), null, 1));
console.log('logbook entries', ds.logbookEntries.length);
