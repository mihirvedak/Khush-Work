# OBX x Faclon - Operations Demo Kit (for Claude Code)

Everything needed to build the OBX client demo in Claude Code: domain knowledge (skill), seeded dummy data (TypeScript), full form schema, design theme and module-by-module build prompts.

## 1. Set up (5 minutes)
1. Unzip into an empty folder, e.g. `obx-demo/`, and open it in VS Code / Cursor / JetBrains.
2. `git init && git add . && git commit -m "chore: demo kit"`
3. Node 20+ installed. Start Claude Code in the folder (`claude` in the terminal, or the IDE extension).
4. Check Claude sees the kit: type `/` - you should see `p0-scaffold` ... `p10-polish`. Ask: "What skills do you have for this project?" - it should list `obx-faclon-ops-demo`.

## 2. Build
Run the slash commands in order, one per session (`/clear` between):

| Command | Builds | Time |
|---|---|---|
| `/p0-scaffold` | Vite app, data layer, store, selectors, tests | 20-30 min |
| `/p1-shell` | Faclon theme, app shell, filters, shared components, `/_kitchen-sink` | 45-60 min |
| `/p2-overview` | Overview / needs-attention | 20 min |
| `/p3-timeline` | Machine Timeline (Hamilton-style, fixed) | 60 min |
| `/p4-downtime` | Downtime Logger | 40 min |
| `/p5-quality-loss` | Quality Loss & Disposition ("rejection") Logger | 40 min |
| `/p6-oee` | OEE dashboards (batch-aware) | 45 min |
| `/p7-process` | Process parameters, SPC, Cp/Cpk, golden tunnel, deviations, solvent balance | 60-90 min |
| `/p8-logbooks` | Schema-driven logbooks (14 forms) + escalation | 60-90 min |
| `/p9-genealogy` | Batch genealogy (demo finale) | 30 min |
| `/p10-polish` | Guided demo mode, QA, accessibility, deploy | 45 min |

Add extra instructions after any command, e.g. `/p3-timeline start with L2-WFE-2M only`.
After each: review the diff, `npm run dev`, click through, `npm run check`, commit.

## 3. What is in the kit
| Path | Content |
|---|---|
| `CLAUDE.md` | Project memory Claude Code loads every session |
| `.claude/skills/obx-faclon-ops-demo/SKILL.md` | Skill entry: read order, stack, 10 hard rules |
| `.claude/skills/.../references/00-09` | Solution overview & storyline, line knowledge, timeline, loggers, OEE, SPC/golden tunnel, logbooks/escalation, data model, design theme, **form schema (every field)** |
| `.claude/commands/p0..p10` | Build prompts as slash commands |
| `prompts/BUILD-PROMPTS.md` | Same prompts in one file (for Lovable / other tools) |
| `seed-data/*.ts` | `types.ts`, `generator.ts`, `forms.ts` (14 forms, 279 fields), `index.ts` (`buildDataset()`), `export-samples.ts` |
| `seed-data/sample/*.json` | Pre-generated slices: full 30-day dataset, WFE-2M 24 h timeline, OEE summary, series, golden tunnel, capability, Pareto, open items, **forms_schema.json**, **logbook_entries.json** |
| `docs/OBX_Demo_Data_Step1_Master_Data.xlsx` | Human-readable master data + form fields + filled examples, for review with sales / OBX |

## 4. Before showing OBX
Confirm with OBX (or keep the "demo" labels on): L1 downstream / L2 asset naming, all non-SOP limits, exact column order of FOR-BIP-009/010/004/003, SOP-BIP-004 vs 006 scope, D8 acid/heptane factors.
